/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "INS_task.h"
#include "balance_task.h"
#include "uart1_log.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
osThreadId defaultTaskHandle;
uint32_t defaultTaskBuffer[ 512 ];
osStaticThreadDef_t defaultTaskControlBlock;
osThreadId INS_TASKHandle;
uint32_t INS_TASKBuffer[ 1024 ];
osStaticThreadDef_t INS_TASKControlBlock;
osThreadId BALANCE_TASKHandle;
uint32_t BALANCE_TASKBuffer[ 1024 ];
osStaticThreadDef_t BALANCE_TASKControlBlock;
osThreadId UART1_LOG_TASKHandle;
uint32_t UART1_LOG_TASKBuffer[ 768 ];
osStaticThreadDef_t UART1_LOG_TASKBlock;
osMessageQId cliEvtQHandle;
uint8_t cliEvtQBuffer[ 64 * sizeof( void * ) ];
osStaticMessageQDef_t cliEvtQControlBlock;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void const * argument);
void INS_Task_Entry(void const * argument);
void Balance_Task_Entry(void const * argument);
void UART1_Log_Task_Entry(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* definition and creation of cliEvtQ */
  osMessageQStaticDef(cliEvtQ, 64, void *, cliEvtQBuffer, &cliEvtQControlBlock);
  cliEvtQHandle = osMessageCreate(osMessageQ(cliEvtQ), NULL);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadStaticDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 512, defaultTaskBuffer, &defaultTaskControlBlock);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* definition and creation of INS_TASK */
  osThreadStaticDef(INS_TASK, INS_Task_Entry, osPriorityRealtime, 0, 1024, INS_TASKBuffer, &INS_TASKControlBlock);
  INS_TASKHandle = osThreadCreate(osThread(INS_TASK), NULL);

  /* definition and creation of BALANCE_TASK */
  osThreadStaticDef(BALANCE_TASK, Balance_Task_Entry, osPriorityAboveNormal, 0, 1024, BALANCE_TASKBuffer, &BALANCE_TASKControlBlock);
  BALANCE_TASKHandle = osThreadCreate(osThread(BALANCE_TASK), NULL);

  /* definition and creation of UART1_LOG_TASK */
  osThreadStaticDef(UART1_LOG_TASK, UART1_Log_Task_Entry, osPriorityLow, 0, 768, UART1_LOG_TASKBuffer, &UART1_LOG_TASKBlock);
  UART1_LOG_TASKHandle = osThreadCreate(osThread(UART1_LOG_TASK), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_INS_Task_Entry */
/**
* @brief Function implementing the INS_TASK thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_INS_Task_Entry */
void INS_Task_Entry(void const * argument)
{
  /* USER CODE BEGIN INS_Task_Entry */
  INS_task();
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END INS_Task_Entry */
}

/* USER CODE BEGIN Header_Balance_Task_Entry */
/**
* @brief Function implementing the BALANCE_TASK thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Balance_Task_Entry */
void Balance_Task_Entry(void const * argument)
{
  /* USER CODE BEGIN Balance_Task_Entry */
  Balance_Task();
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END Balance_Task_Entry */
}

/* USER CODE BEGIN Header_UART1_Log_Task_Entry */
/**
* @brief Function implementing the UART1_LOG_TASK thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_UART1_Log_Task_Entry */
void UART1_Log_Task_Entry(void const * argument)
{
  /* USER CODE BEGIN UART1_Log_Task_Entry */
  UART1_LogTask(argument);
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END UART1_Log_Task_Entry */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */
