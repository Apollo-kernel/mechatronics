/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "oled_font.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
float ELEC_inv=0.0f;
float ELEC_inc=0.0f;
float ELEC_outc=0.0f;
float ELEC_capv=0.0f;
float ELEC_capc=0.0f;
float ELEC_capp=0.0f;
float ELEC_inp=0.0f;
float ADC_VALUE=0.0f;
float ELEC_inp_capp=0.0f;
float ELEC_pe=0.0f;

/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for OledTimer */
osTimerId_t OledTimerHandle;
const osTimerAttr_t OledTimer_attributes = {
  .name = "OledTimer"
};
/* Definitions for msTimer */
osTimerId_t msTimerHandle;
const osTimerAttr_t msTimer_attributes = {
  .name = "msTimer"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);
void OledCallback(void *argument);
void msTimerCallback(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* Create the timer(s) */
  /* creation of OledTimer */
  OledTimerHandle = osTimerNew(OledCallback, osTimerPeriodic, NULL, &OledTimer_attributes);

  /* creation of msTimer */
  msTimerHandle = osTimerNew(msTimerCallback, osTimerPeriodic, NULL, &msTimer_attributes);

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  osTimerStart(OledTimerHandle,100);
  osTimerStart(msTimerHandle,10);
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartDefaultTask */
}

/* OledCallback function */
void OledCallback(void *argument)
{
  /* USER CODE BEGIN OledCallback */

  /* USER CODE END OledCallback */
}

/* msTimerCallback function */
void msTimerCallback(void *argument)
{
  /* USER CODE BEGIN msTimerCallback */
  ++FPS_Count;
  //	DrawNum(80,0, FPS, 3);

  //			DrawNum(60,2, cap_v.valu[1], 5);
  //			DrawNum(60,4, cap_c.valu[1], 5);
  OLED_Showdecimal(9,0,debug_float[0],1,1);
  OLED_Showdecimal(18,2,ELEC_inv,2,1);
  OLED_Showdecimal(84,2,ELEC_capv,2,1);
  OLED_Showdecimal(18,4,ELEC_inc,2,1);
  OLED_Showdecimal(84,4,ELEC_capc,2,1);
  //	OLED_Showdecimal(18,6,ELEC_outc,2,1);
  OLED_Showdecimal(18,6,ELEC_inp,2,1);
  OLED_Showdecimal(84,6,ELEC_capp,2,1);
  OLED_Showdecimal(102,0,ELEC_inp_capp,1,1);
  OLED_Showdecimal(48,0,ELEC_pe,2,1);

  //	HAL_GPIO_TogglePin(LED_G_GPIO_Port,LED_G_Pin);
  //	HAL_GPIO_TogglePin(LED_R_GPIO_Port,LED_R_Pin);
  HAL_I2C_Mem_Write_DMA(&hi2c3, OLED_ADDRESS, 0x40, I2C_MEMADD_SIZE_8BIT, ScreenBuffer[0], SCREEN_PAGE_NUM * SCREEN_PAGEDATA_NUM);

  /* USER CODE END msTimerCallback */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

